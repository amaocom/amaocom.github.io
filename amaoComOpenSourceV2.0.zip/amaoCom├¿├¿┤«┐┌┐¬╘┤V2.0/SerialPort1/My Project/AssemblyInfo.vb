﻿Imports System.Resources

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' 有关程序集的常规信息通过下列属性集
' 控制。更改这些属性值可修改
' 与程序集关联的信息。

' 查看程序集属性的值

<Assembly: AssemblyTitle("功夫猫串口调试助手1.4.0")> 
<Assembly: AssemblyDescription("说明：本软件仅供学习交流使用，严禁用于非法买卖、传播或其他商业用途. 使用过程中如遇任何问题、BUG或建议，请QQ或邮件联系本人. amaomails@163.com,wjw123abc@163.com.2015/12/16")> 
<Assembly: AssemblyCompany("")> 
<Assembly: AssemblyProduct("功夫猫串口调试助手V1.4.0  作者：amao")> 
<Assembly: AssemblyCopyright("amaomails@163.com")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)> 

'如果此项目向 COM 公开，则下列 GUID 用于类型库的 ID
<Assembly: Guid("2aec2ac1-b018-4bec-aa57-833514bdaea1")> 

' 程序集的版本信息由下面四个值组成:
'
'      主版本
'      次版本
'      内部版本号
'      修订号
'
' 可以指定所有这些值，也可以使用“内部版本号”和“修订号”的默认值，
' 方法是按如下所示使用“*”:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("0.1.4.0")> 
<Assembly: AssemblyFileVersion("0.0.0.0")> 

<Assembly: NeutralResourcesLanguageAttribute("az-Cyrl-AZ")> 